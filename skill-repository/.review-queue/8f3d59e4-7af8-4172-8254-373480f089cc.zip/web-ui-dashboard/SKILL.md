---
name: web-ui-dashboard
description: Skill für React-basierte Dashboards und Diagramme zur Visualisierung von Anomalie-Daten. Trigger bei: (1) Erstellung von Dashboards für Maschinendaten, (2) Visualisierung von Zeitreihen mit Anomalien, (3) Interaktive Anomalie-Bewertung durch Benutzer, (4) MUI-basierte React-Komponenten. Verwendet MUI (Material-UI) und MUI-Icons, keine Authentifizierung erforderlich.
---
abc
# Web UI Dashboard Skill

Erstelle React-Dashboards für Anomalie-Visualisierung mit MUI-Komponenten.

## Stack

- React 18+ (ohne Build-Step, via CDN)
- Material-UI (MUI) v5 mit Icons
- Recharts für Diagramme
- Kein Node.js-Server erforderlich (statisches HTML)

## Verzeichnisstruktur

```
/workspace/server/
├── index.html              # Haupt-Dashboard
├── components/             # React-Komponenten (optional)
└── api/                    # FastAPI-Endpoints
```

## React-Komponenten mit CDN (kein Build)

Da kein Node.js-Server verwendet wird, nutzen wir CDN-Links für React und MUI.

### Basis-Template (index.html)

```html
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anomaly Dashboard</title>
    
    <!-- React -->
    <script crossorigin src="https://unpkg.com/react@18/umd/react.production.min.js"></script>
    <script crossorigin src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script>
    
    <!-- Babel für JSX -->
    <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
    
    <!-- MUI -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <script crossorigin src="https://unpkg.com/@mui/material@5/umd/material-ui.production.min.js"></script>
    
    <!-- Recharts -->
    <script crossorigin src="https://unpkg.com/recharts@2/umd/Recharts.min.js"></script>
    
    <style>
        body { margin: 0; font-family: 'Roboto', sans-serif; background: #f5f5f5; }
        #root { min-height: 100vh; }
    </style>
</head>
<body>
    <div id="root"></div>
    
    <script type="text/babel">
        // React-App hier
    </script>
</body>
</html>
```

## Haupt-Dashboard-Komponente

```jsx
const { useState, useEffect, useMemo } = React;
const { 
    ThemeProvider, createTheme, CssBaseline,
    AppBar, Toolbar, Typography, Container, Grid, Paper, Box,
    Card, CardContent, CardActions, Button, IconButton,
    Chip, Alert, CircularProgress, Snackbar,
    Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
    Dialog, DialogTitle, DialogContent, DialogActions,
    FormControl, InputLabel, Select, MenuItem, Slider,
    Tooltip, Badge
} = MaterialUI;

const {
    LineChart, Line, XAxis, YAxis, CartesianGrid, 
    Tooltip: RechartsTooltip, Legend, ResponsiveContainer,
    Scatter, ScatterChart, ReferenceLine, Brush,
    ComposedChart, Area
} = Recharts;

// API-Konfiguration
const API_BASE = window.location.pathname.split('/').slice(0, 2).join('/') + '/api';

// Theme
const theme = createTheme({
    palette: {
        primary: { main: '#1976d2' },
        secondary: { main: '#dc004e' },
        success: { main: '#4caf50' },
        warning: { main: '#ff9800' },
        error: { main: '#f44336' },
    },
});

// Status-Farben
const STATUS_COLORS = {
    unreviewed: '#ff9800',
    confirmed: '#f44336',
    dismissed: '#4caf50'
};

// Anomalie-Dashboard Komponente
function AnomalyDashboard({ dataset }) {
    const [data, setData] = useState([]);
    const [anomalies, setAnomalies] = useState({ anomalies: [], anomaly_count: 0 });
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [selectedAnomaly, setSelectedAnomaly] = useState(null);
    const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
    const [selectedFeature, setSelectedFeature] = useState('');
    const [scoreThreshold, setScoreThreshold] = useState(0);

    // Daten laden
    useEffect(() => {
        async function loadData() {
            try {
                setLoading(true);
                
                // Alle Datenpunkte laden
                const dataRes = await fetch(`${API_BASE}/${dataset}`);
                if (!dataRes.ok) throw new Error('Daten konnten nicht geladen werden');
                const dataJson = await dataRes.json();
                setData(dataJson);
                
                // Anomalien laden
                const anomalyRes = await fetch(`${API_BASE}/${dataset}?action=anomalies`);
                if (!anomalyRes.ok) throw new Error('Anomalien konnten nicht geladen werden');
                const anomalyJson = await anomalyRes.json();
                setAnomalies(anomalyJson);
                
                // Erstes Feature auswählen
                if (anomalyJson.feature_columns?.length > 0) {
                    setSelectedFeature(anomalyJson.feature_columns[0]);
                }
                
                setLoading(false);
            } catch (err) {
                setError(err.message);
                setLoading(false);
            }
        }
        loadData();
    }, [dataset]);

    // Anomalie-Review aktualisieren
    async function updateAnomalyStatus(id, status) {
        try {
            const res = await fetch(`${API_BASE}/${dataset}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id, status })
            });
            
            if (!res.ok) throw new Error('Update fehlgeschlagen');
            
            // Lokalen State aktualisieren
            setAnomalies(prev => ({
                ...prev,
                anomalies: prev.anomalies.map(a => 
                    a.id === id ? { ...a, status } : a
                )
            }));
            
            setSnackbar({
                open: true,
                message: `Anomalie ${id} als "${status}" markiert`,
                severity: 'success'
            });
            
            setSelectedAnomaly(null);
        } catch (err) {
            setSnackbar({
                open: true,
                message: err.message,
                severity: 'error'
            });
        }
    }

    // Gefilterte Anomalien
    const filteredAnomalies = useMemo(() => {
        return anomalies.anomalies?.filter(a => a.anomaly_score >= scoreThreshold) || [];
    }, [anomalies, scoreThreshold]);

    // Chart-Daten mit Anomalie-Markierung
    const chartData = useMemo(() => {
        if (!data.length || !selectedFeature) return [];
        
        return data.map((d, idx) => ({
            ...d,
            index: idx,
            value: d.values?.[selectedFeature],
            anomalyMarker: d.is_anomaly ? d.values?.[selectedFeature] : null,
            timestamp: d.timestamp ? new Date(d.timestamp).toLocaleString() : idx
        }));
    }, [data, selectedFeature]);

    // Statistiken
    const stats = useMemo(() => {
        const total = anomalies.anomalies?.length || 0;
        const confirmed = anomalies.anomalies?.filter(a => a.status === 'confirmed').length || 0;
        const dismissed = anomalies.anomalies?.filter(a => a.status === 'dismissed').length || 0;
        const unreviewed = anomalies.anomalies?.filter(a => a.status === 'unreviewed').length || 0;
        return { total, confirmed, dismissed, unreviewed };
    }, [anomalies]);

    if (loading) {
        return (
            <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '50vh' }}>
                <CircularProgress />
            </Box>
        );
    }

    if (error) {
        return <Alert severity="error">{error}</Alert>;
    }

    return (
        <Box>
            {/* Statistik-Karten */}
            <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item xs={3}>
                    <Card>
                        <CardContent>
                            <Typography color="textSecondary" gutterBottom>Datenpunkte</Typography>
                            <Typography variant="h4">{anomalies.total_records}</Typography>
                        </CardContent>
                    </Card>
                </Grid>
                <Grid item xs={3}>
                    <Card>
                        <CardContent>
                            <Typography color="textSecondary" gutterBottom>Anomalien</Typography>
                            <Typography variant="h4" color="warning.main">{stats.total}</Typography>
                        </CardContent>
                    </Card>
                </Grid>
                <Grid item xs={3}>
                    <Card>
                        <CardContent>
                            <Typography color="textSecondary" gutterBottom>Bestätigt</Typography>
                            <Typography variant="h4" color="error.main">{stats.confirmed}</Typography>
                        </CardContent>
                    </Card>
                </Grid>
                <Grid item xs={3}>
                    <Card>
                        <CardContent>
                            <Typography color="textSecondary" gutterBottom>Abgelehnt</Typography>
                            <Typography variant="h4" color="success.main">{stats.dismissed}</Typography>
                        </CardContent>
                    </Card>
                </Grid>
            </Grid>

            {/* Filter */}
            <Paper sx={{ p: 2, mb: 3 }}>
                <Grid container spacing={2} alignItems="center">
                    <Grid item xs={4}>
                        <FormControl fullWidth size="small">
                            <InputLabel>Feature</InputLabel>
                            <Select
                                value={selectedFeature}
                                label="Feature"
                                onChange={(e) => setSelectedFeature(e.target.value)}
                            >
                                {anomalies.feature_columns?.map(col => (
                                    <MenuItem key={col} value={col}>{col}</MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={6}>
                        <Typography gutterBottom>Anomalie-Score Schwellwert: {scoreThreshold.toFixed(2)}</Typography>
                        <Slider
                            value={scoreThreshold}
                            onChange={(e, v) => setScoreThreshold(v)}
                            min={0}
                            max={1}
                            step={0.01}
                            marks={[
                                { value: 0, label: '0' },
                                { value: 0.5, label: '0.5' },
                                { value: 1, label: '1' }
                            ]}
                        />
                    </Grid>
                </Grid>
            </Paper>

            {/* Zeitreihen-Chart */}
            <Paper sx={{ p: 2, mb: 3 }}>
                <Typography variant="h6" gutterBottom>Zeitreihe: {selectedFeature}</Typography>
                <ResponsiveContainer width="100%" height={400}>
                    <ComposedChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis 
                            dataKey="index" 
                            label={{ value: 'Index', position: 'bottom' }}
                        />
                        <YAxis 
                            label={{ value: selectedFeature, angle: -90, position: 'insideLeft' }}
                        />
                        <RechartsTooltip 
                            content={({ active, payload }) => {
                                if (!active || !payload?.length) return null;
                                const d = payload[0].payload;
                                return (
                                    <Paper sx={{ p: 1 }}>
                                        <Typography variant="body2">Index: {d.index}</Typography>
                                        <Typography variant="body2">{selectedFeature}: {d.value?.toFixed(4)}</Typography>
                                        <Typography variant="body2">Score: {d.anomaly_score?.toFixed(4)}</Typography>
                                        {d.is_anomaly && (
                                            <Chip label="Anomalie" color="warning" size="small" />
                                        )}
                                    </Paper>
                                );
                            }}
                        />
                        <Legend />
                        <Line 
                            type="monotone" 
                            dataKey="value" 
                            stroke="#1976d2" 
                            dot={false}
                            name={selectedFeature}
                        />
                        <Scatter 
                            dataKey="anomalyMarker" 
                            fill="#f44336" 
                            name="Anomalien"
                            onClick={(data) => {
                                const anomaly = anomalies.anomalies.find(a => a.id === data.index);
                                if (anomaly) setSelectedAnomaly(anomaly);
                            }}
                        />
                        <Brush dataKey="index" height={30} stroke="#1976d2" />
                    </ComposedChart>
                </ResponsiveContainer>
            </Paper>

            {/* Anomalie-Tabelle */}
            <Paper sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>
                    Anomalien ({filteredAnomalies.length})
                </Typography>
                <TableContainer sx={{ maxHeight: 400 }}>
                    <Table stickyHeader size="small">
                        <TableHead>
                            <TableRow>
                                <TableCell>ID</TableCell>
                                <TableCell>Timestamp</TableCell>
                                <TableCell>Score</TableCell>
                                <TableCell>Status</TableCell>
                                <TableCell>Aktionen</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {filteredAnomalies.map(anomaly => (
                                <TableRow 
                                    key={anomaly.id}
                                    hover
                                    selected={selectedAnomaly?.id === anomaly.id}
                                    onClick={() => setSelectedAnomaly(anomaly)}
                                    sx={{ cursor: 'pointer' }}
                                >
                                    <TableCell>{anomaly.id}</TableCell>
                                    <TableCell>
                                        {anomaly.timestamp ? new Date(anomaly.timestamp).toLocaleString() : '-'}
                                    </TableCell>
                                    <TableCell>
                                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                            <Box 
                                                sx={{ 
                                                    width: 50, 
                                                    height: 8, 
                                                    bgcolor: '#e0e0e0',
                                                    borderRadius: 1,
                                                    overflow: 'hidden'
                                                }}
                                            >
                                                <Box 
                                                    sx={{ 
                                                        width: `${anomaly.anomaly_score * 100}%`, 
                                                        height: '100%',
                                                        bgcolor: anomaly.anomaly_score > 0.7 ? 'error.main' : 
                                                                 anomaly.anomaly_score > 0.4 ? 'warning.main' : 'success.main'
                                                    }}
                                                />
                                            </Box>
                                            {anomaly.anomaly_score.toFixed(3)}
                                        </Box>
                                    </TableCell>
                                    <TableCell>
                                        <Chip 
                                            label={anomaly.status}
                                            size="small"
                                            sx={{ 
                                                bgcolor: STATUS_COLORS[anomaly.status],
                                                color: 'white'
                                            }}
                                        />
                                    </TableCell>
                                    <TableCell>
                                        <Button
                                            size="small"
                                            color="error"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                updateAnomalyStatus(anomaly.id, 'confirmed');
                                            }}
                                            disabled={anomaly.status === 'confirmed'}
                                        >
                                            Bestätigen
                                        </Button>
                                        <Button
                                            size="small"
                                            color="success"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                updateAnomalyStatus(anomaly.id, 'dismissed');
                                            }}
                                            disabled={anomaly.status === 'dismissed'}
                                        >
                                            Ablehnen
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            </Paper>

            {/* Detail-Dialog */}
            <Dialog 
                open={!!selectedAnomaly} 
                onClose={() => setSelectedAnomaly(null)}
                maxWidth="md"
                fullWidth
            >
                {selectedAnomaly && (
                    <>
                        <DialogTitle>
                            Anomalie #{selectedAnomaly.id}
                            <Chip 
                                label={selectedAnomaly.status}
                                size="small"
                                sx={{ 
                                    ml: 2,
                                    bgcolor: STATUS_COLORS[selectedAnomaly.status],
                                    color: 'white'
                                }}
                            />
                        </DialogTitle>
                        <DialogContent>
                            <Grid container spacing={2}>
                                <Grid item xs={6}>
                                    <Typography variant="subtitle2">Timestamp</Typography>
                                    <Typography>
                                        {selectedAnomaly.timestamp ? 
                                            new Date(selectedAnomaly.timestamp).toLocaleString() : '-'}
                                    </Typography>
                                </Grid>
                                <Grid item xs={6}>
                                    <Typography variant="subtitle2">Anomalie-Score</Typography>
                                    <Typography color="error">
                                        {selectedAnomaly.anomaly_score.toFixed(4)}
                                    </Typography>
                                </Grid>
                                <Grid item xs={12}>
                                    <Typography variant="subtitle2">Messwerte</Typography>
                                    <TableContainer>
                                        <Table size="small">
                                            <TableBody>
                                                {Object.entries(selectedAnomaly.values || {}).map(([key, val]) => (
                                                    <TableRow key={key}>
                                                        <TableCell>{key}</TableCell>
                                                        <TableCell>{val?.toFixed(4) ?? 'N/A'}</TableCell>
                                                    </TableRow>
                                                ))}
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                </Grid>
                            </Grid>
                        </DialogContent>
                        <DialogActions>
                            <Button onClick={() => setSelectedAnomaly(null)}>
                                Schließen
                            </Button>
                            <Button 
                                color="success"
                                variant="contained"
                                onClick={() => updateAnomalyStatus(selectedAnomaly.id, 'dismissed')}
                                disabled={selectedAnomaly.status === 'dismissed'}
                            >
                                Als Normal markieren
                            </Button>
                            <Button 
                                color="error"
                                variant="contained"
                                onClick={() => updateAnomalyStatus(selectedAnomaly.id, 'confirmed')}
                                disabled={selectedAnomaly.status === 'confirmed'}
                            >
                                Als Anomalie bestätigen
                            </Button>
                        </DialogActions>
                    </>
                )}
            </Dialog>

            {/* Snackbar */}
            <Snackbar
                open={snackbar.open}
                autoHideDuration={3000}
                onClose={() => setSnackbar(s => ({ ...s, open: false }))}
            >
                <Alert severity={snackbar.severity}>{snackbar.message}</Alert>
            </Snackbar>
        </Box>
    );
}

// Haupt-App
function App() {
    const [datasets, setDatasets] = useState([]);
    const [selectedDataset, setSelectedDataset] = useState('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Verfügbare API-Module laden
        fetch(API_BASE + '/')
            .then(res => res.json())
            .then(data => {
                const modules = data.modules || [];
                setDatasets(modules);
                if (modules.length > 0) {
                    setSelectedDataset(modules[0]);
                }
                setLoading(false);
            })
            .catch(err => {
                console.error(err);
                setLoading(false);
            });
    }, []);

    return (
        <ThemeProvider theme={theme}>
            <CssBaseline />
            <AppBar position="static">
                <Toolbar>
                    <Typography variant="h6" sx={{ flexGrow: 1 }}>
                        Anomaly Detection Dashboard
                    </Typography>
                    {datasets.length > 0 && (
                        <FormControl size="small" sx={{ minWidth: 200, bgcolor: 'white', borderRadius: 1 }}>
                            <Select
                                value={selectedDataset}
                                onChange={(e) => setSelectedDataset(e.target.value)}
                            >
                                {datasets.map(ds => (
                                    <MenuItem key={ds} value={ds}>{ds}</MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                    )}
                </Toolbar>
            </AppBar>
            
            <Container maxWidth="xl" sx={{ mt: 3, mb: 3 }}>
                {loading ? (
                    <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
                        <CircularProgress />
                    </Box>
                ) : selectedDataset ? (
                    <AnomalyDashboard key={selectedDataset} dataset={selectedDataset} />
                ) : (
                    <Alert severity="info">
                        Keine Datasets gefunden. Bitte analysieren Sie zuerst CSV-Dateien.
                    </Alert>
                )}
            </Container>
        </ThemeProvider>
    );
}

// App rendern
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
    </script>
</body>
</html>
```

## Komponenten-Übersicht

### AnomalyDashboard
Hauptkomponente mit:
- Statistik-Karten (Datenpunkte, Anomalien, bestätigt, abgelehnt)
- Feature-Auswahl und Score-Schwellwert
- Interaktives Zeitreihen-Diagramm
- Anomalie-Tabelle mit Aktionen
- Detail-Dialog für einzelne Anomalien

### API-Integration
Die Komponenten verwenden automatisch die relative API-URL basierend auf dem aktuellen Pfad:
```javascript
const API_BASE = window.location.pathname.split('/').slice(0, 2).join('/') + '/api';
```

### Status-Workflow
Anomalien durchlaufen drei Status:
1. `unreviewed` (orange) - Neu erkannt
2. `confirmed` (rot) - Vom Benutzer als echte Anomalie bestätigt
3. `dismissed` (grün) - Vom Benutzer als normal markiert

## Anpassungen

### Weitere Charts hinzufügen

```jsx
// Anomalie-Score-Verteilung
<BarChart data={scoreDistribution}>
    <XAxis dataKey="range" />
    <YAxis />
    <Bar dataKey="count" fill="#1976d2" />
</BarChart>

// Multi-Feature-Vergleich
<ScatterChart>
    <XAxis dataKey="feature1" />
    <YAxis dataKey="feature2" />
    <Scatter data={data} fill="#1976d2" />
</ScatterChart>
```

### Dark Mode

```jsx
const theme = createTheme({
    palette: {
        mode: 'dark',
        // ...
    }
});
```

## MUI-Icons verwenden

```jsx
// Icons sind über MaterialUI verfügbar
const { Warning, CheckCircle, Cancel, Refresh } = MaterialUI;

// Verwendung
<IconButton><Warning color="warning" /></IconButton>
```

## Abhängigkeiten (via CDN)

- React 18
- React DOM 18
- Babel Standalone (für JSX)
- MUI 5 (material-ui.production.min.js)
- Recharts 2
- Roboto Font
- Material Icons
